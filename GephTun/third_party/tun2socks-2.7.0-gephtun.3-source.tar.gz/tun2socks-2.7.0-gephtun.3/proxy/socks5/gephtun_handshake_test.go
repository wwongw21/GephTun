package socks5

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	M "github.com/xjasonlyu/tun2socks/v2/metadata"
	wire "github.com/xjasonlyu/tun2socks/v2/transport/socks5"
	"io"
	"net"
	"net/netip"
	"testing"
	"time"
)

func TestAuditConstructorRejectsShortEndpoints(t *testing.T) {
	for _, addr := range []string{"", "x"} {
		t.Run(addr, func(t *testing.T) {
			defer func() {
				if v := recover(); v != nil {
					t.Errorf("constructor panicked for short endpoint %q: %v", addr, v)
				}
			}()
			_, err := New(addr, "", "")
			if err == nil {
				t.Errorf("invalid short endpoint %q did not return error", addr)
			}
		})
	}
}

func TestAuditSOCKSHandshakeRespectsContextCancellation(t *testing.T) {
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { listener.Close() })
	accepted := make(chan net.Conn, 1)
	go func() {
		c, e := listener.Accept()
		if e == nil {
			accepted <- c
		}
	}()
	ss, err := New(listener.Addr().String(), "", "")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	result := make(chan error, 1)
	go func() {
		c, e := ss.DialContext(ctx, &M.Metadata{Network: M.TCP, DstIP: netip.MustParseAddr("192.0.2.1"), DstPort: 443})
		if c != nil {
			c.Close()
		}
		result <- e
	}()
	var peer net.Conn
	select {
	case peer = <-accepted:
	case <-time.After(time.Second):
		t.Fatal("proxy connection not accepted")
	}
	t.Cleanup(func() { peer.Close() })
	// Cancel only after TCP connects, to exercise the pending SOCKS response.
	cancel()
	select {
	case e := <-result:
		if e == nil {
			t.Fatal("canceled handshake returned success")
		}
	case <-time.After(500 * time.Millisecond):
		peer.Close()
		<-result
		t.Fatal("SOCKS handshake remained blocked after its context was canceled")
	}
}

func TestAuditConstructorPreservesSupportedEndpoints(t *testing.T) {
	for _, item := range []struct {
		input, want string
		unix        bool
	}{
		{"127.0.0.1:1080", "127.0.0.1:1080", false},
		{"[::1]:1080", "[::1]:1080", false},
		{"/tmp/proxy.sock", "/tmp/proxy.sock", true},
		{"/@proxy", "@proxy", true},
		{"/\x00proxy", "\x00proxy", true},
	} {
		ss, err := New(item.input, "", "")
		if err != nil || ss.addr != item.want || ss.unix != item.unix {
			t.Fatalf("supported endpoint %q changed: proxy=%+v err=%v", item.input, ss, err)
		}
	}
}

func TestAuditSOCKSHandshakeRespectsContextDeadline(t *testing.T) {
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { listener.Close() })
	accepted := make(chan net.Conn, 1)
	go func() {
		c, e := listener.Accept()
		if e == nil {
			accepted <- c
		}
	}()
	ss, err := New(listener.Addr().String(), "", "")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 80*time.Millisecond)
	defer cancel()
	result := make(chan error, 1)
	go func() {
		c, e := ss.DialContext(ctx, &M.Metadata{Network: M.TCP, DstIP: netip.MustParseAddr("192.0.2.1"), DstPort: 443})
		if c != nil {
			c.Close()
		}
		result <- e
	}()
	var peer net.Conn
	select {
	case peer = <-accepted:
	case <-time.After(time.Second):
		t.Fatal("proxy connection not accepted")
	}
	t.Cleanup(func() { peer.Close() })
	select {
	case e := <-result:
		if e == nil {
			t.Fatal("expired handshake returned success")
		}
	case <-time.After(time.Second):
		peer.Close()
		<-result
		t.Fatal("SOCKS handshake exceeded its context deadline")
	}
}

func TestAuditCompletedSOCKSHandshakeLeavesConnectionUsable(t *testing.T) {
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { listener.Close() })
	serverDone := make(chan error, 1)
	go func() {
		peer, e := listener.Accept()
		if e != nil {
			serverDone <- e
			return
		}
		defer peer.Close()
		peer.SetDeadline(time.Now().Add(2 * time.Second))
		greeting := make([]byte, 3)
		if _, e = io.ReadFull(peer, greeting); e != nil {
			serverDone <- e
			return
		}
		if _, e = peer.Write([]byte{5, 0}); e != nil {
			serverDone <- e
			return
		}
		request := make([]byte, 10)
		if _, e = io.ReadFull(peer, request); e != nil {
			serverDone <- e
			return
		}
		if _, e = peer.Write([]byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0}); e != nil {
			serverDone <- e
			return
		}
		payload := make([]byte, 4)
		if _, e = io.ReadFull(peer, payload); e == nil {
			_, e = peer.Write(payload)
		}
		serverDone <- e
	}()
	ss, err := New(listener.Addr().String(), "", "")
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 80*time.Millisecond)
	defer cancel()
	client, err := ss.DialContext(ctx, &M.Metadata{Network: M.TCP, DstIP: netip.MustParseAddr("192.0.2.1"), DstPort: 443})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { client.Close() })
	cancel()
	time.Sleep(100 * time.Millisecond)
	if _, err = client.Write([]byte("ping")); err != nil {
		t.Fatalf("completed connection retained handshake cancellation/deadline: %v", err)
	}
	payload := make([]byte, 4)
	if _, err = io.ReadFull(client, payload); err != nil || string(payload) != "ping" {
		t.Fatalf("completed connection unusable: payload=%q err=%v", payload, err)
	}
	if err = <-serverDone; err != nil {
		t.Fatal(err)
	}
}

func TestAuditUDPAssociateHandshakeIsBounded(t *testing.T) {
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { listener.Close() })
	accepted := make(chan net.Conn, 1)
	// Complete greeting, then withhold UDP ASSOCIATE reply.
	go func() {
		peer, e := listener.Accept()
		if e != nil {
			return
		}
		accepted <- peer
		greeting := make([]byte, 3)
		if _, e = io.ReadFull(peer, greeting); e == nil {
			peer.Write([]byte{5, 0})
		}
	}()
	ss, err := New(listener.Addr().String(), "", "")
	if err != nil {
		t.Fatal(err)
	}
	result := make(chan error, 1)
	go func() {
		pc, e := ss.DialUDP(&M.Metadata{Network: M.UDP, DstIP: netip.MustParseAddr("192.0.2.1"), DstPort: 443})
		if pc != nil {
			pc.Close()
		}
		result <- e
	}()
	var peer net.Conn
	select {
	case peer = <-accepted:
	case <-time.After(time.Second):
		t.Fatal("proxy connection not accepted")
	}
	t.Cleanup(func() { peer.Close() })
	select {
	case e := <-result:
		if e == nil {
			t.Fatal("stalled UDP handshake returned success")
		}
	case <-time.After(6 * time.Second):
		peer.Close()
		<-result
		t.Fatal("UDP ASSOCIATE handshake was not bounded by the five-second connection budget")
	}
}

func TestAuditUDPAssociateSuccessSurvivesHandshakeAndTracksControlClose(t *testing.T) {
	relay, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { relay.Close() })
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { listener.Close() })
	type serverResult struct {
		peer net.Conn
		err  error
	}
	server := make(chan serverResult, 1)
	go func() {
		peer, e := listener.Accept()
		if e != nil {
			server <- serverResult{err: e}
			return
		}
		peer.SetDeadline(time.Now().Add(2 * time.Second))
		serve := func() error {
			greeting := make([]byte, 3)
			if _, e := io.ReadFull(peer, greeting); e != nil {
				return e
			}
			if _, e := peer.Write([]byte{5, 0}); e != nil {
				return e
			}
			request := make([]byte, 10)
			if _, e := io.ReadFull(peer, request); e != nil {
				return e
			}
			if request[1] != byte(wire.CmdUDPAssociate) {
				return fmt.Errorf("received command %d, expected UDP ASSOCIATE", request[1])
			}
			response := append([]byte{5, 0, 0}, wire.ParseAddr(relay.LocalAddr())...)
			if _, e := peer.Write(response); e != nil {
				return e
			}
			return peer.SetDeadline(time.Time{})
		}
		e = serve()
		if e != nil {
			peer.Close()
		}
		server <- serverResult{peer: peer, err: e}
	}()
	ss, err := New(listener.Addr().String(), "", "")
	if err != nil {
		t.Fatal(err)
	}
	pc, err := ss.DialUDP(&M.Metadata{Network: M.UDP, DstIP: netip.MustParseAddr("192.0.2.5"), DstPort: 443})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { pc.Close() })
	state := <-server
	if state.err != nil {
		t.Fatal(state.err)
	}
	t.Cleanup(func() { state.peer.Close() })
	// A successful association must survive the DialUDP defer and its old
	// five-second handshake deadline while retaining the TCP control socket.
	time.Sleep(5*time.Second + 100*time.Millisecond)
	relay.SetDeadline(time.Now().Add(2 * time.Second))
	pc.SetDeadline(time.Now().Add(2 * time.Second))
	target := &net.UDPAddr{IP: net.IPv4(192, 0, 2, 5), Port: 443}
	if _, err = pc.WriteTo([]byte("request"), target); err != nil {
		t.Fatalf("successful association closed after handshake: %v", err)
	}
	b := make([]byte, 1024)
	n, from, err := relay.ReadFrom(b)
	if err != nil {
		t.Fatal(err)
	}
	address, payload, err := wire.DecodeUDPPacket(b[:n])
	if err != nil || address.String() != target.String() || string(payload) != "request" {
		t.Fatalf("bad outgoing packet: addr=%v payload=%q err=%v", address, payload, err)
	}
	if _, err = relay.WriteTo(regressionPacket(t, "response"), from); err != nil {
		t.Fatal(err)
	}
	n, from, err = pc.ReadFrom(b)
	if err != nil || from.String() != target.String() || string(b[:n]) != "response" {
		t.Fatalf("bad association response: address=%v n=%d err=%v", from, n, err)
	}
	state.peer.Close()
	pc.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, _, err = pc.ReadFrom(b); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("closing SOCKS control TCP did not close UDP association: %v", err)
	}
}

type auditWritePacketConn struct {
	scriptedPacketConn
	count   int
	err     error
	written []byte
}

func (pc *auditWritePacketConn) WriteTo(b []byte, _ net.Addr) (int, error) {
	pc.written = append([]byte(nil), b...)
	if pc.count < 0 {
		return len(b), pc.err
	}
	return pc.count, pc.err
}

func TestAuditUDPWriteToReportsPayloadBytes(t *testing.T) {
	target := &net.UDPAddr{IP: net.IP{192, 0, 2, 5}, Port: 443}
	for _, tc := range []struct {
		name      string
		payload   []byte
		count     int
		err       error
		wantCount int
		wantErr   error
	}{
		{"success", []byte("hello"), -1, nil, 5, nil},
		{"empty-payload", nil, -1, nil, 0, nil},
		{"write-error", []byte("hello"), 0, io.ErrClosedPipe, 0, io.ErrClosedPipe},
		{"short-write", []byte("hello"), 12, nil, 2, io.ErrShortWrite},
		{"partial-write-error", []byte("hello"), 12, io.ErrClosedPipe, 2, io.ErrClosedPipe},
	} {
		t.Run(tc.name, func(t *testing.T) {
			wireConn := &auditWritePacketConn{count: tc.count, err: tc.err}
			pc := &socksPacketConn{PacketConn: wireConn, rAddr: target}
			n, err := pc.WriteTo(tc.payload, target)
			if n != tc.wantCount || !errors.Is(err, tc.wantErr) {
				t.Fatalf("payload count/error mismatch: got n=%d err=%v, want n=%d err=%v", n, err, tc.wantCount, tc.wantErr)
			}
			addr, payload, decodeErr := wire.DecodeUDPPacket(wireConn.written)
			if decodeErr != nil || addr.String() != target.String() || !bytes.Equal(payload, tc.payload) {
				t.Fatalf("wire encoding changed: addr=%v payload=%q err=%v", addr, payload, decodeErr)
			}
		})
	}
}
