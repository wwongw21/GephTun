package socks5

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net"
	"net/netip"
	"os"
	"runtime"
	"sync"
	"testing"
	"time"

	M "github.com/xjasonlyu/tun2socks/v2/metadata"
	wire "github.com/xjasonlyu/tun2socks/v2/transport/socks5"
)

type auditServer struct {
	listener net.Listener
	mu       sync.Mutex
	peers    map[string]net.Conn
	workers  sync.WaitGroup
	stopped  chan struct{}
	once     sync.Once
}

func newAuditServer(t *testing.T, handler func(net.Conn)) *auditServer {
	t.Helper()
	ln, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	s := &auditServer{listener: ln, peers: make(map[string]net.Conn), stopped: make(chan struct{})}
	go func() {
		defer close(s.stopped)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			key := c.RemoteAddr().String()
			s.mu.Lock()
			s.peers[key] = c
			s.mu.Unlock()
			s.workers.Add(1)
			go func() {
				defer s.workers.Done()
				defer c.Close()
				defer func() { s.mu.Lock(); delete(s.peers, key); s.mu.Unlock() }()
				c.SetDeadline(time.Now().Add(5 * time.Second))
				handler(c)
			}()
		}
	}()
	t.Cleanup(s.close)
	return s
}
func (s *auditServer) close() {
	s.once.Do(func() {
		s.listener.Close()
		<-s.stopped
		s.mu.Lock()
		for _, c := range s.peers {
			c.Close()
		}
		s.mu.Unlock()
		s.workers.Wait()
	})
}
func (s *auditServer) closePeer(key string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	c, ok := s.peers[key]
	if ok {
		c.Close()
	}
	return ok
}
func (s *auditServer) active() int { s.mu.Lock(); defer s.mu.Unlock(); return len(s.peers) }
func (s *auditServer) waitIdle(t *testing.T) {
	t.Helper()
	until := time.Now().Add(2 * time.Second)
	for s.active() != 0 && time.Now().Before(until) {
		time.Sleep(time.Millisecond)
	}
	if n := s.active(); n != 0 {
		t.Fatalf("%d server sockets remained after clients finished", n)
	}
}
func auditServerRequest(c net.Conn) (byte, error) {
	greeting := make([]byte, 3)
	if _, err := io.ReadFull(c, greeting); err != nil {
		return 0, err
	}
	if !bytes.Equal(greeting, []byte{5, 1, 0}) {
		return 0, fmt.Errorf("unexpected greeting %x", greeting)
	}
	if _, err := c.Write([]byte{5, 0}); err != nil {
		return 0, err
	}
	header := make([]byte, 3)
	if _, err := io.ReadFull(c, header); err != nil {
		return 0, err
	}
	if _, err := wire.ReadAddr(c, make([]byte, wire.MaxAddrLen)); err != nil {
		return 0, err
	}
	return header[1], nil
}
func auditMetadata() *M.Metadata {
	return &M.Metadata{Network: M.TCP, DstIP: netip.MustParseAddr("192.0.2.5"), DstPort: 443}
}
func auditFDCount() int {
	if runtime.GOOS != "linux" {
		return -1
	}
	entries, err := os.ReadDir("/proc/self/fd")
	if err != nil {
		return -1
	}
	return len(entries)
}

func TestGephTunConcurrentCanceledHandshakesReleaseSockets(t *testing.T) {
	const clients = 128
	greetings := make(chan struct{}, clients)
	server := newAuditServer(t, func(c net.Conn) {
		greeting := make([]byte, 3)
		if _, err := io.ReadFull(c, greeting); err != nil {
			return
		}
		greetings <- struct{}{}
		io.Copy(io.Discard, c)
	})
	ss, _ := New(server.listener.Addr().String(), "", "")
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	results := make(chan error, clients)
	for i := 0; i < clients; i++ {
		go func() {
			c, err := ss.DialContext(ctx, auditMetadata())
			if c != nil {
				c.Close()
			}
			results <- err
		}()
	}
	for i := 0; i < clients; i++ {
		select {
		case <-greetings:
		case <-time.After(3 * time.Second):
			t.Fatal("not all clients reached SOCKS greeting")
		}
	}
	cancel()
	for i := 0; i < clients; i++ {
		select {
		case err := <-results:
			if !errors.Is(err, context.Canceled) {
				t.Fatalf("canceled client returned %v", err)
			}
		case <-time.After(2 * time.Second):
			t.Fatal("canceled handshake remained blocked")
		}
	}
	server.waitIdle(t)
	t.Logf("%d simultaneous canceled handshakes released their server sockets", clients)
}

func TestGephTunConcurrentTCPFragmentedRepliesAndData(t *testing.T) {
	const clients = 64
	server := newAuditServer(t, func(c net.Conn) {
		cmd, err := auditServerRequest(c)
		if err != nil || cmd != 1 {
			return
		}
		for _, b := range []byte{5, 0, 0, 1, 0, 0, 0, 0, 0, 0} {
			if _, err := c.Write([]byte{b}); err != nil {
				return
			}
		}
		io.Copy(c, c)
	})
	ss, _ := New(server.listener.Addr().String(), "", "")
	results := make(chan error, clients)
	for i := 0; i < clients; i++ {
		go func(id int) {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			c, err := ss.DialContext(ctx, auditMetadata())
			cancel()
			if err != nil {
				results <- err
				return
			}
			defer c.Close()
			c.SetDeadline(time.Now().Add(2 * time.Second))
			payload := []byte(fmt.Sprintf("client-%03d", id))
			if _, err = c.Write(payload); err != nil {
				results <- err
				return
			}
			reply := make([]byte, len(payload))
			_, err = io.ReadFull(c, reply)
			if err == nil && !bytes.Equal(payload, reply) {
				err = fmt.Errorf("TCP payload mismatch")
			}
			results <- err
		}(i)
	}
	for i := 0; i < clients; i++ {
		if err := <-results; err != nil {
			t.Fatal(err)
		}
	}
	server.waitIdle(t)
	t.Logf("%d concurrent TCP streams accepted fragmented replies and exchanged data after dial context cancellation", clients)
}

func TestGephTunConcurrentUDPAssociationsAndControlClose(t *testing.T) {
	const clients = 64
	const packets = 8
	relay, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan struct{})
	go func() {
		defer close(done)
		buf := make([]byte, 65535)
		for {
			n, from, err := relay.ReadFrom(buf)
			if err != nil {
				return
			}
			if _, err = relay.WriteTo(buf[:n], from); err != nil {
				return
			}
		}
	}()
	t.Cleanup(func() { relay.Close(); <-done })
	server := newAuditServer(t, func(c net.Conn) {
		cmd, err := auditServerRequest(c)
		if err != nil || cmd != 3 {
			return
		}
		if _, err = c.Write(append([]byte{5, 0, 0}, wire.ParseAddr(relay.LocalAddr())...)); err != nil {
			return
		}
		io.Copy(io.Discard, c)
	})
	ss, _ := New(server.listener.Addr().String(), "", "")
	results := make(chan error, clients)
	target := &net.UDPAddr{IP: net.IP{192, 0, 2, 5}, Port: 443}
	for i := 0; i < clients; i++ {
		go func(id int) {
			pc, err := ss.DialUDP(auditMetadata())
			if err != nil {
				results <- err
				return
			}
			defer pc.Close()
			pc.SetDeadline(time.Now().Add(3 * time.Second))
			buf := make([]byte, 256)
			for seq := 0; seq < packets; seq++ {
				payload := []byte(fmt.Sprintf("client-%03d-packet-%02d", id, seq))
				n, err := pc.WriteTo(payload, target)
				if err != nil || n != len(payload) {
					results <- fmt.Errorf("UDP send count=%d err=%v", n, err)
					return
				}
				n, from, err := pc.ReadFrom(buf)
				if err != nil || from.String() != target.String() || !bytes.Equal(payload, buf[:n]) {
					results <- fmt.Errorf("UDP receive mismatch n=%d err=%v", n, err)
					return
				}
			}
			if id%2 == 0 {
				control := pc.(*socksPacketConn).tcpConn
				if !server.closePeer(control.LocalAddr().String()) {
					results <- fmt.Errorf("server control socket vanished")
					return
				}
			} else {
				pc.Close()
			}
			pc.SetReadDeadline(time.Now().Add(time.Second))
			_, _, err = pc.ReadFrom(buf)
			if !errors.Is(err, net.ErrClosed) {
				results <- fmt.Errorf("UDP survived control/owner close: %v", err)
				return
			}
			results <- nil
		}(i)
	}
	for i := 0; i < clients; i++ {
		if err := <-results; err != nil {
			t.Fatal(err)
		}
	}
	server.waitIdle(t)
	t.Logf("%d UDP associations, %d datagram round trips; server control close and caller close both released associations", clients, clients*packets)
}

func TestGephTunInvalidUDPBindingReleasesResources(t *testing.T) {
	server := newAuditServer(t, func(c net.Conn) {
		cmd, err := auditServerRequest(c)
		if err != nil || cmd != 3 {
			return
		}
		reply := append([]byte{5, 0, 0}, wire.SerializeAddr("relay.invalid", netip.Addr{}, 1080)...)
		if _, err = c.Write(reply); err != nil {
			return
		}
		io.Copy(io.Discard, c)
	})
	ss, _ := New(server.listener.Addr().String(), "", "")
	runtime.GC()
	beforeFD := auditFDCount()
	beforeGo := runtime.NumGoroutine()
	const requests = 128
	results := make(chan error, requests)
	for i := 0; i < requests; i++ {
		go func() {
			pc, err := ss.DialUDP(auditMetadata())
			if pc != nil {
				pc.Close()
			}
			if err == nil {
				err = fmt.Errorf("unsupported UDP binding accepted")
			} else {
				err = nil
			}
			results <- err
		}()
	}
	for i := 0; i < requests; i++ {
		if err := <-results; err != nil {
			t.Fatal(err)
		}
	}
	server.waitIdle(t)
	until := time.Now().Add(2 * time.Second)
	for time.Now().Before(until) {
		if runtime.NumGoroutine() <= beforeGo+2 && (beforeFD < 0 || auditFDCount() <= beforeFD) {
			break
		}
		time.Sleep(time.Millisecond)
	}
	afterFD := auditFDCount()
	afterGo := runtime.NumGoroutine()
	if beforeFD >= 0 && afterFD > beforeFD {
		t.Fatalf("UDP binding failures leaked descriptors: before=%d after=%d", beforeFD, afterFD)
	}
	if afterGo > beforeGo+2 {
		t.Fatalf("UDP binding failures left goroutines: before=%d after=%d", beforeGo, afterGo)
	}
	t.Logf("%d simultaneous failed associations: descriptors %d -> %d, goroutines %d -> %d", requests, beforeFD, afterFD, beforeGo, afterGo)
}

func TestGephTunMalformedReplyClosesTCP(t *testing.T) {
	for _, tc := range []struct {
		name   string
		header []byte
	}{{"wrong-version", []byte{4, 0, 0}}, {"reserved-byte", []byte{5, 0, 1}}} {
		t.Run(tc.name, func(t *testing.T) {
			server := newAuditServer(t, func(c net.Conn) {
				if _, err := auditServerRequest(c); err != nil {
					return
				}
				c.Write(append(tc.header, []byte{1, 127, 0, 0, 1, 4, 56}...))
				io.Copy(io.Discard, c)
			})
			ss, _ := New(server.listener.Addr().String(), "", "")
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			c, err := ss.DialContext(ctx, auditMetadata())
			if c != nil {
				c.Close()
			}
			if err == nil {
				t.Fatal("malformed SOCKS reply was reported as a successful connection")
			}
			server.waitIdle(t)
		})
	}
}

func TestGephTunDatagramMutationBounds(t *testing.T) {
	const cases = 100000
	rng := rand.New(rand.NewSource(17092026))
	relay := &net.UDPAddr{IP: net.IP{127, 0, 0, 1}, Port: 43210}
	buf := make([]byte, 512)
	for i := 0; i < cases; i++ {
		size := rng.Intn(256)
		packet := make([]byte, size)
		rng.Read(packet)
		if i%3 == 0 && size >= 10 {
			packet[0] = 0
			packet[1] = 0
			packet[2] = 0
			packet[3] = 1
		}
		rng.Read(buf)
		pc := &socksPacketConn{PacketConn: &scriptedPacketConn{queue: []queuedDatagram{{packet, relay}}}, rAddr: relay}
		n, from, err := pc.ReadFrom(buf)
		if n < 0 || n > len(packet) || n > len(buf) {
			t.Fatalf("invalid count %d for packet length %d", n, len(packet))
		}
		if err != nil && n != 0 {
			t.Fatalf("error returned nonzero count %d", n)
		}
		if err == nil && from == nil {
			t.Fatal("successful datagram has no source")
		}
	}
	t.Logf("%d deterministic datagram mutations stayed within current-packet bounds", cases)
}
