package socks5

import (
	"bytes"
	"io"
	"net"
	"net/netip"
	"testing"
	"time"

	wire "github.com/xjasonlyu/tun2socks/v2/transport/socks5"
)

type queuedDatagram struct {
	data []byte
	from net.Addr
}

type scriptedPacketConn struct{ queue []queuedDatagram }

func (s *scriptedPacketConn) ReadFrom(b []byte) (int, net.Addr, error) {
	if len(s.queue) == 0 {
		return 0, nil, io.EOF
	}
	d := s.queue[0]
	s.queue = s.queue[1:]
	return copy(b, d.data), d.from, nil
}
func (*scriptedPacketConn) WriteTo([]byte, net.Addr) (int, error) { return 0, io.ErrClosedPipe }
func (*scriptedPacketConn) Close() error                          { return nil }
func (*scriptedPacketConn) LocalAddr() net.Addr                   { return &net.UDPAddr{} }
func (*scriptedPacketConn) SetDeadline(time.Time) error           { return nil }
func (*scriptedPacketConn) SetReadDeadline(time.Time) error       { return nil }
func (*scriptedPacketConn) SetWriteDeadline(time.Time) error      { return nil }

func regressionPacket(t *testing.T, payload string) []byte {
	t.Helper()
	a := wire.SerializeAddr("", netip.MustParseAddr("192.0.2.5"), 443)
	b, err := wire.EncodeUDPPacket(a, []byte(payload))
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func TestReadFromDiscardsForeignRelay(t *testing.T) {
	relay := &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 43210}
	for name, sender := range map[string]net.Addr{
		"wrong-port": &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 43211},
		"wrong-IP":   &net.UDPAddr{IP: net.IPv4(127, 0, 0, 2), Port: 43210},
		"nil-sender": nil,
	} {
		t.Run(name, func(t *testing.T) {
			pc := &socksPacketConn{
				PacketConn: &scriptedPacketConn{queue: []queuedDatagram{
					{regressionPacket(t, "injected"), sender},
					{regressionPacket(t, "expected"), relay},
				}},
				rAddr: relay,
			}
			b := make([]byte, 1024)
			n, addr, err := pc.ReadFrom(b)
			if err != nil || n != len("expected") || !bytes.Equal(b[:max(n, 0)], []byte("expected")) || addr.String() != "192.0.2.5:443" {
				t.Fatalf("foreign relay was not ignored: n=%d, address=%v, err=%v, payload=%q", n, addr, err, b[:max(n, 0)])
			}
		})
	}
}

func TestReadFromRejectsTruncatedDatagramInReusedBuffer(t *testing.T) {
	relay := &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 43210}
	for size := 0; size < 10; size++ {
		t.Run(string(rune('A'+size)), func(t *testing.T) {
			packet := regressionPacket(t, "old data in reused receive buffer")
			b := make([]byte, 1024)
			copy(b, packet)
			pc := &socksPacketConn{
				PacketConn: &scriptedPacketConn{queue: []queuedDatagram{{packet[:size], relay}}},
				rAddr:      relay,
			}
			n, _, err := pc.ReadFrom(b)
			if err == nil || n != 0 {
				t.Fatalf("truncated datagram accepted using stale bytes: datagram=%d, returned=%d, err=%v", size, n, err)
			}
		})
	}
}

func TestReadFromUsesCurrentDatagramLength(t *testing.T) {
	relay := &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 43210}
	pc := &socksPacketConn{
		PacketConn: &scriptedPacketConn{queue: []queuedDatagram{{regressionPacket(t, "ok"), relay}}},
		rAddr:      relay,
	}
	b := bytes.Repeat([]byte{0x7f}, 128)
	n, addr, err := pc.ReadFrom(b)
	if err != nil || n != 2 || addr.String() != "192.0.2.5:443" || string(b[:n]) != "ok" {
		t.Fatalf("valid datagram failed: n=%d address=%v err=%v", n, addr, err)
	}
	// Only the current payload may be copied back; the remaining buffer is
	// caller-owned scratch space and must not be shifted from stale data.
	if b[20] != 0x7f {
		t.Fatal("unrelated buffer contents unexpectedly overwritten")
	}
}

func TestSOCKSUDPActualDatagramRoundTrip(t *testing.T) {
	relay, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { relay.Close() })
	client, err := net.ListenPacket("udp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { client.Close() })
	relay.SetDeadline(time.Now().Add(3 * time.Second))
	client.SetDeadline(time.Now().Add(3 * time.Second))
	pc := &socksPacketConn{PacketConn: client, rAddr: relay.LocalAddr()}
	target := &net.UDPAddr{IP: net.IPv4(192, 0, 2, 5), Port: 443}
	if _, err := pc.WriteTo([]byte("request"), target); err != nil {
		t.Fatal(err)
	}
	b := make([]byte, 1024)
	n, from, err := relay.ReadFrom(b)
	if err != nil {
		t.Fatal(err)
	}
	a, payload, err := wire.DecodeUDPPacket(b[:n])
	if err != nil || a.String() != target.String() || string(payload) != "request" {
		t.Fatalf("relay received incorrect request: address=%v payload=%q err=%v", a, payload, err)
	}
	if _, err := relay.WriteTo(regressionPacket(t, "response"), from); err != nil {
		t.Fatal(err)
	}
	n, from, err = pc.ReadFrom(b)
	if err != nil || from.String() != target.String() || string(b[:n]) != "response" {
		t.Fatalf("client received incorrect response: address=%v n=%d err=%v", from, n, err)
	}
}
