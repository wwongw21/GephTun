#!/usr/bin/env python3
"""Build the audited GephTun Windows dependency from vendored source."""

import argparse
import hashlib
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--go", default="go", help="Path to the verified Go 1.26.8 executable")
    parser.add_argument("--output", default="build/tun2socks-windows-amd64.exe")
    parser.add_argument("--test", action="store_true", help="Run the complete native Go test suite first")
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    output = Path(args.output).resolve()
    env = os.environ.copy()
    env.update(GOTOOLCHAIN="local", GO111MODULE="on", GOPROXY="off", GOSUMDB="off",
               CGO_ENABLED="0", GOFLAGS="", GOEXPERIMENT="", GOFIPS140="off")
    version = subprocess.check_output([args.go, "version"], text=True, env=env)
    if version.split()[2] != "go1.26.8":
        raise SystemExit("This build requires the verified Go 1.26.8 toolchain.")
    if args.test:
        native = env.copy()
        native.pop("GOOS", None)
        native.pop("GOARCH", None)
        subprocess.run([args.go, "test", "-mod=vendor", "./...", "-count=1"],
                       cwd=source, env=native, check=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    env.update(GOOS="windows", GOARCH="amd64", GOAMD64="v1")
    module = "github.com/xjasonlyu/tun2socks/v2/internal/version"
    ldflags = ("-s -w -buildid= "
               f"-X {module}.Version=2.7.0-gephtun.3 "
               f"-X {module}.GitCommit=8dda19e8e4613e014f0b12f3e624fdff5e5f23b3+gephtun.3")
    subprocess.run([args.go, "build", "-mod=vendor", "-trimpath", "-buildvcs=false",
                    "-ldflags", ldflags, "-o", str(output), "."],
                   cwd=source, env=env, check=True)
    print(f"{hashlib.sha256(output.read_bytes()).hexdigest()}  {output}")


if __name__ == "__main__":
    main()
