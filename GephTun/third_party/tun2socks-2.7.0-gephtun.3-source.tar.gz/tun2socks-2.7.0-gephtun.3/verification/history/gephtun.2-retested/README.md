# Fresh audit of the uploaded .2 engine

The uploaded .2 source manifest verified all 1,643 entries. Its fresh vendored
rebuild matched the uploaded .2 executable exactly. The protocol overlay added
the new table test without modifying .2 code: four cases failed as expected.
The lifecycle overlay ran two real-socket malformed-reply cases; both also
failed as expected. The overlay paths in receipts record the actual audit
workspace; recreate those path mappings when replaying elsewhere. The preserved
test snapshots use `.go.txt` so Go does not discover them as runnable packages.
Current .3 results are in `../../gephtun.3/`, and current runnable tests are in
the regular `proxy/socks5/` and `transport/socks5/` source directories.
