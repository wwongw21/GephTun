from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,sys,argparse
base=Path(__file__).resolve().parent;go='/workspace/scratch/b4191ee3e51c/dependency-build/go/bin/go'
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--source',default=str(base/'source/tun2socks-2.7.0-gephtun.2'));p.add_argument('--race',action='store_true');p.add_argument('--count',type=int,default=1);p.add_argument('--run');p.add_argument('--overlay');p.add_argument('--packages',default='./...');p.add_argument('--build',action='store_true');p.add_argument('--vet',action='store_true');a=p.parse_args();source=Path(a.source);env=os.environ.copy();env.update(GOTOOLCHAIN='local',GO111MODULE='on',GOPROXY='off',GOSUMDB='off',CGO_ENABLED='1' if a.race else '0',GOFLAGS='',GOEXPERIMENT='',GOFIPS140='off',GOCACHE=str(base/'go-cache'),GOMODCACHE=str(base/'empty-module-cache'));env.pop('GOOS',None);env.pop('GOARCH',None)
if a.build:cmd=[sys.executable,str(source/'build-gephtun.py'),'--go',go,'--test','--output',str(base/(a.name+'.exe'))]
elif a.vet:cmd=[go,'vet','-mod=vendor','./...']
else:
 cmd=[go,'test','-mod=vendor','-json',a.packages,'-count='+str(a.count),'-shuffle=17092026','-timeout=120s']
 if a.race:cmd.append('-race')
 if a.run:cmd.append('-run='+a.run)
 if a.overlay:cmd.append('-overlay='+a.overlay)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 entries=[p.relative_to(source).as_posix()+':'+sha(p) for p in sorted(source.rglob('*')) if p.is_file() and (p.suffix=='.go' or p.name in ['go.mod','go.sum','modules.txt','build-gephtun.py'])];return hashlib.sha256('\n'.join(entries).encode()).hexdigest()
start_inputs=inputs();log=base/(a.name+'.log');at=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic();rc=None
with log.open('w') as f:
 try:r=subprocess.run(cmd,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300);rc=r.returncode
 except subprocess.TimeoutExpired:f.write('\nHOST RUNNER TIMEOUT\n')
result={'name':a.name,'at_utc':at,'command':cmd,'source':str(source),'source_code_inputs_sha256':start_inputs,'source_unchanged_during_run':start_inputs==inputs(),'go_version':'1.26.8','environment':{k:env[k] for k in ['GOTOOLCHAIN','GOPROXY','GOSUMDB','CGO_ENABLED','GOCACHE','GOMODCACHE']},'returncode':rc,'status':'PASS' if rc==0 else 'FAIL','duration_seconds':round(time.monotonic()-start,3),'log_sha256':sha(log)}
if a.overlay:result['overlay_sha256']=sha(Path(a.overlay));result['overlay_sources']={v:sha(Path(v)) for v in json.loads(Path(a.overlay).read_text())['Replace'].values()}
if a.build and rc==0:result['binary_sha256']=sha(base/(a.name+'.exe'));result['binary_size']=(base/(a.name+'.exe')).stat().st_size
if not a.build and not a.vet:
 events=[]
 for line in log.read_text().splitlines():
  try:events.append(json.loads(line))
  except ValueError:pass
 result.update(passed_test_entries=sum(e.get('Action')=='pass' and 'Test' in e for e in events),passed_top_level_tests=sum(e.get('Action')=='pass' and 'Test' in e and '/' not in e['Test'] for e in events),passed_test_packages=sum(e.get('Action')=='pass' and 'Test' not in e for e in events),failed_events=[e for e in events if e.get('Action')=='fail'])
(base/(a.name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
