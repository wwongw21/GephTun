from pathlib import Path
import json,re,hashlib,datetime
base=Path('/workspace/scratch/6c4e0dabb50d/audit-1.3.4/dependency')
def versions(v):
    v=v.removeprefix('go').removeprefix('v').split('+')[0]
    if v=='0':v='0.0.0'
    main,_,pre=v.partition('-');parts=tuple(map(int,main.split('.')))
    return parts+(1 if not pre else 0,tuple((0,int(p)) if p.isdigit() else (1,p) for p in pre.split('.')) if pre else ())
def parse_json_objects(raw):
    d=json.JSONDecoder();items=[];pos=0
    while pos<len(raw):
        while pos<len(raw) and raw[pos].isspace():pos+=1
        if pos==len(raw):break
        v,pos=d.raw_decode(raw,pos);items.append(v)
    return items
packages=parse_json_objects((base/'windows-packages.json-stream').read_text());package_names={p['ImportPath'] for p in packages}
mods={p['Module']['Path']:p['Module']['Version'].removeprefix('v') for p in packages if 'Module' in p and not p['Module'].get('Main')};mods['stdlib']='1.26.8'
index=json.loads((base/'vuln-modules.json').read_text());candidates=[]
for row in index:
    if row['path'] not in mods:continue
    for entry in row['vulns']:
        if not entry.get('fixed') or versions(entry['fixed'])>versions(mods[row['path']]):candidates.append(entry['id'])
missing=[];checked=[];alerts=[]
for vid in sorted(set(candidates)):
    path=base/'advisories'/f'{vid}.json'
    if not path.exists():missing.append(vid);continue
    record=json.loads(path.read_text());checked.append({'id':vid,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    if record.get('withdrawn'):continue
    for affected in record.get('affected',[]):
        module=affected['package']['name']
        if module not in mods:continue
        applicable=False
        for rng in affected.get('ranges',[]):
            if rng['type']!='SEMVER':continue
            active=False
            for event in rng['events']:
                if 'introduced' in event and versions(mods[module])>=versions(event['introduced']):active=True
                if 'fixed' in event and versions(mods[module])>=versions(event['fixed']):active=False
                if 'last_affected' in event and versions(mods[module])>versions(event['last_affected']):active=False
                if 'limit' in event and versions(mods[module])>=versions(event['limit']):active=False
            applicable=applicable or active
        if applicable:
            affected_packages=[p['path'] for p in affected.get('ecosystem_specific',{}).get('imports',[])];alerts.append({'id':vid,'module':module,'version':mods[module],'affected_built_packages':sorted(package_names.intersection(affected_packages)),'affected_packages':affected_packages,'summary':record.get('summary','')})
result={'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Fresh official Go module index, semver range filtering including prerelease/pseudo versions, current Windows package membership; not a symbol call-graph scan.','database':'https://vuln.go.dev/index/modules.json','database_sha256':hashlib.sha256((base/'vuln-modules.json').read_bytes()).hexdigest(),'module_versions':mods,'windows_package_count':len(packages),'candidate_advisory_count':len(set(candidates)),'checked_advisories':checked,'unread_candidates':missing,'module_range_alerts':alerts,'affected_built_package_alert_count':sum(bool(a['affected_built_packages']) for a in alerts),'status':'INCONCLUSIVE' if missing else ('ALERT' if any(a['affected_built_packages'] for a in alerts) else 'PASS'),'limitations':['Only publicly recorded Go database findings are considered.','Package exclusion narrows module-level alerts; this is not malware scanning, a full application audit, Windows execution, or a full symbol call-graph scan.','Locally identified SOCKS handshake defects are handled by GephTun .3 even though absent from the upstream advisory endpoint.']}
(base/'vulnerability-screen.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
