from pathlib import Path
import os,subprocess,hashlib,json,tarfile,urllib.request,zipfile,io,concurrent.futures,datetime
base=Path(__file__).resolve().parent;pkg=base.parent/'GephTun';src=base/'source/tun2socks-2.7.0-gephtun.3';runtime=Path('/workspace/scratch/b4191ee3e51c/dependency-build');go=str(runtime/'go/bin/go')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
archive=runtime/'go1.26.8.linux-amd64.tar.gz';downloads=json.loads((base/'go-downloads.json').read_text());release=next(v for v in downloads if v['version']=='go1.26.8');record=next(x for x in release['files'] if x['filename']==archive.name);bad=[];checked=0
with tarfile.open(archive) as t:
 for e in t:
  if e.isfile():
   p=runtime/e.name
   if not p.exists() or hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(t.extractfile(e).read()).digest():bad.append(e.name)
   checked+=1
write(base/'toolchain-integrity.json',{'archive_sha256':sha(archive),'official_sha256':record['sha256'],'files_checked':checked,'file_mismatches':bad,'status':'PASS' if sha(archive)==record['sha256'] and not bad else 'FAIL'})
# Current Windows package membership is read from source without executing target code.
env=os.environ.copy();env.update(GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off',GOOS='windows',GOARCH='amd64',GOAMD64='v1',CGO_ENABLED='0',GOCACHE=str(base/'go-cache'),GOMODCACHE=str(base/'empty-module-cache'))
r=subprocess.run([go,'list','-mod=vendor','-buildvcs=false','-deps','-json','.'],cwd=src,env=env,text=True,capture_output=True);assert r.returncode==0,r.stderr;(base/'windows-packages.json-stream').write_text(r.stdout)
# Refresh official advisory records selected by the unchanged current index.
old=Path('/workspace/scratch/6c4e0dabb50d/audit/dependency-advisories');out=base/'advisories';out.mkdir(exist_ok=True)
def fetch_advisory(p):
 url='https://vuln.go.dev/ID/'+p.name
 with urllib.request.urlopen(url,timeout=20) as f:b=f.read()
 (out/p.name).write_bytes(b);return {'id':p.stem,'url':url,'sha256':hashlib.sha256(b).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:advisories=list(pool.map(fetch_advisory,sorted(old.glob('*.json'))))
write(base/'advisory-refresh.json',advisories)
# Revalidate the vendor distribution member and the accompanying binary license.
url='https://www.wintun.net/builds/wintun-0.14.1.zip'
with urllib.request.urlopen(url,timeout=20) as f:b=f.read()
with zipfile.ZipFile(io.BytesIO(b)) as z:dll=z.read('wintun/bin/amd64/wintun.dll');license=z.read('wintun/LICENSE.txt')
w={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'url':url,'archive_sha256':hashlib.sha256(b).hexdigest(),'published_sha256':'07c256185d6ee3652e09fa55c0b673e2624b565e02c4b9091c79ca7d2f24ef51','dll_matches_package':dll==(pkg/'bin/wintun.dll').read_bytes(),'license_matches_package':license==(pkg/'licenses/Wintun-LICENSE.txt').read_bytes()};w['status']='PASS' if w['archive_sha256']==w['published_sha256'] and w['dll_matches_package'] and w['license_matches_package'] else 'FAIL';write(base/'wintun-current-identity.json',w)
print('Runtime files:',checked,'mismatches:',len(bad),'fresh advisories:',len(advisories),'Wintun:',w['status'])
