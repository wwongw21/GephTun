# Current .3 receipts

These receipts and raw logs were produced from the newly uploaded .2 source
plus the documented .3 patch. Their source-code-input hash is captured before
execution and checked again after execution. Current source tests, modules,
vendor and builder were frozen before these runs. Documentation and archived
evidence were then completed and the enclosing archive independently rebuilt.
The enclosing package carries that final archive-to-executable receipt outside
the source archive to avoid circular hashes. Historical results elsewhere in
`verification/history/` are not counted as fresh .3 tests. Runner scripts and
absolute paths are retained as audit records; source tests and the pinned
builder are the portable reproduction entry points.
