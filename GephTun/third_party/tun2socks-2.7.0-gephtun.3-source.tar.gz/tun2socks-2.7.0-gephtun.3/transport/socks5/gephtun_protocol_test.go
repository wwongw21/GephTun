package socks5

import (
	"bytes"
	"io"
	"testing"
)

type auditHandshakeIO struct {
	io.Reader
	io.Writer
}

func TestGephTunHandshakeServerValidation(t *testing.T) {
	validReply := []byte{5, 0, 0, 1, 127, 0, 0, 1, 4, 56}
	cases := []struct {
		name     string
		response []byte
		user     *User
		valid    bool
	}{
		{"valid-no-auth", append([]byte{5, 0}, validReply...), nil, true},
		{"wrong-reply-version", append([]byte{5, 0}, append([]byte{4, 0, 0}, validReply[3:]...)...), nil, false},
		{"nonzero-reply-reserved", append([]byte{5, 0}, append([]byte{5, 0, 1}, validReply[3:]...)...), nil, false},
		{"unoffered-no-auth", append([]byte{5, 0}, validReply...), &User{Username: "user", Password: "password"}, false},
		{"valid-userpass", append([]byte{5, 2, 1, 0}, validReply...), &User{Username: "user", Password: "password"}, true},
		{"wrong-userpass-version", append([]byte{5, 2, 5, 0}, validReply...), &User{Username: "user", Password: "password"}, false},
		{"rejected-auth", []byte{5, 2, 1, 1}, &User{Username: "user", Password: "password"}, false},
		{"unoffered-auth", []byte{5, 2}, nil, false},
		{"no-methods", []byte{5, 255}, nil, false},
		{"wrong-greeting-version", []byte{4, 0}, nil, false},
		{"short-reply", []byte{5, 0, 5, 0}, nil, false},
	}
	target := []byte{1, 192, 0, 2, 5, 1, 187}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var sent bytes.Buffer
			addr, err := ClientHandshake(&auditHandshakeIO{bytes.NewReader(tc.response), &sent}, target, CmdConnect, tc.user)
			if tc.valid {
				if err != nil || addr.String() != "127.0.0.1:1080" {
					t.Fatalf("valid handshake failed: address=%v err=%v", addr, err)
				}
			} else if err == nil {
				t.Fatalf("invalid server message was accepted: address=%v", addr)
			}
			if tc.name == "unoffered-no-auth" && sent.Len() != 3 {
				t.Fatalf("connection request followed an unoffered method: %d bytes sent", sent.Len())
			}
		})
	}
}
